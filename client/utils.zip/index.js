const { initialize } = require("./windows");
initialize();
