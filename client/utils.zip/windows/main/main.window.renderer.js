const { ipcRenderer } = require("electron");

const uiState = {
  searchBarVisible: false,
  user: null
};

ipcRenderer.on("app-start", function(state) {
  uiState.user = state.user;
});
